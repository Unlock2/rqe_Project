package first.common.service;

import java.util.List;
import java.util.Map;

public interface CommonService {

	Map dataSheetListDetail() throws Exception;
	
	List Comprehensive() throws Exception;
	
	
}

package first.sample.service;

import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;

public interface SampleService {

	List dataSheetList() throws Exception;

	

	
}
